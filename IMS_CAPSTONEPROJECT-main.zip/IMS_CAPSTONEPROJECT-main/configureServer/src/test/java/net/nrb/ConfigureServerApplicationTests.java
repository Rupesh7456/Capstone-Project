package net.nrb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigureServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
