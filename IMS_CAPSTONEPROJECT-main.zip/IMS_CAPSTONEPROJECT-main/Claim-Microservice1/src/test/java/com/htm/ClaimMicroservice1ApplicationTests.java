package com.htm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimMicroservice1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
